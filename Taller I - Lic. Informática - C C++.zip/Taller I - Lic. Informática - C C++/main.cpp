#include <stdio.h>
#include "archivo.h"
#include "fecha.h"


int main()
{
    string s,s2;
    fecha f,f2;
    strcrear (s);
    strcrear (s2);
    scan (s);
    print (s);
    if (!esAlfabetico (s))
        printf ("\nNo es alfa");
    else
        printf ("\nEs alfa");

        /*
    if (!stringEsFecha (s))
        printf ("No es fecha");
    else
        printf ("Es fecha");

    printf ("\n");
    scan (s2);
    print (s2);
    f = stringAFecha (s);
    f2 = stringAFecha (s2);
    DesplegarFecha (f);
    DesplegarFecha (f2);
    if (!validarFecha (f) && !validarFecha (f2))
        printf ("Alguna fecha es invalida");
    else
        if (fechaapta (f2,f))
            printf ("Fecha apta");
        else
            printf ("Fecha no apta");
            */
}
