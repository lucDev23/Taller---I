#ifndef STRING_H_INCLUDED
#define STRING_H_INCLUDED
#include "boolean.h"
#include <stdio.h>

const int MAX = 80;
typedef char * string;

void strcrear (string &str);

void strdestruir (string &str);

int strlar(string str);

void print(string str);

void strcop(string &str1,string str2);

void scan(string &str);

boolean strmen(string str1, string str2);

boolean streq(string str1, string str2);

boolean stringEsFecha (string s);

boolean esAlfabetico (string s);

void Bajar_String (string s, FILE * f);
// Escribe en el archivo los caracteres del string s (incluido '\0')
// Precondici�n: El archivo viene abierto para escritura.
void Levantar_String (string &s, FILE * f);
// Lee desde el archivo los caracteres del string s.
// Precondici�n: El archivo viene abierto para lectura.

#endif // STRING_H_INCLUDED
