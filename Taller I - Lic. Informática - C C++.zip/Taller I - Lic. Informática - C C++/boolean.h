#ifndef BOOLEAN_H_INCLUDED
#define BOOLEAN_H_INCLUDED

typedef enum {FALSE,TRUE} boolean;

void cargar(boolean &b);

void mostrar(boolean b);

#endif // BOOLEAN_H_INCLUDED
