#ifndef ARCHIVO_H_INCLUDED
#define ARCHIVO_H_INCLUDED
#include "stringdinamico.h"

boolean Existe (string nomArch);
// Determina si existe o no un archivo con el nombre recibido por par�metro



#endif // ARCHIVO_H_INCLUDED
